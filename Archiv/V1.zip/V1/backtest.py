import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


class Backtester:
    def __init__(self, agent, df_1min, df_5min, df_15min, initial_balance=10000, slippage=0.01, fee_per_trade=0.0001,
                 visualize=False):
        """
        Generic Backtester for trading agents.
        """
        self.agent = agent
        self.df_1min = df_1min
        self.df_5min = df_5min
        self.df_15min = df_15min
        self.initial_balance = initial_balance
        self.slippage = slippage
        self.fee_per_trade = fee_per_trade
        self.visualize = visualize

        self.balance = initial_balance
        self.equity_curve = []
        self.trades = []
        self.current_trade = None

    def run_backtest(self):
        """Run the backtest over the available market data."""
        for i in range(len(self.df_1min)):
            current_time = self.df_1min.index[i]
            df_1min_slice = self.df_1min.iloc[:i + 1]
            df_5min_slice = self.df_5min[self.df_5min.index <= current_time]
            df_15min_slice = self.df_15min[self.df_15min.index <= current_time]

            # Erhalte das Trading-Signal
            signal, stop_loss, take_profit = self.agent.get_signal(df_5min_slice, df_1min_slice, df_15min_slice)

            # Prüfe zuerst, ob der aktuelle Trade geschlossen werden muss
            self._check_exit_conditions(df_1min_slice.iloc[-1])

            # Danach den Trade verwalten oder einen neuen öffnen
            self._manage_trade(signal, stop_loss, take_profit, df_1min_slice.iloc[-1])

            self.equity_curve.append(self.balance)

        return self._calculate_metrics()

    def _check_exit_conditions(self, last_candle):
        """Prüft, ob der aktuelle Trade geschlossen werden muss."""
        if self.current_trade is None:
            return

        trade_type = self.current_trade['type']

        # Prüfe Stop-Loss und Take-Profit für Calls
        if trade_type == "BUY CALL":
            if last_candle['low'] <= self.current_trade['stop_loss']:
                self._close_trade(self.current_trade['stop_loss'] - self.slippage)
            elif last_candle['high'] >= self.current_trade['take_profit']:
                self._close_trade(self.current_trade['take_profit'] - self.slippage)

        # Prüfe Stop-Loss und Take-Profit für Puts
        elif trade_type == "BUY PUT":
            if last_candle['high'] >= self.current_trade['stop_loss']:
                self._close_trade(self.current_trade['stop_loss'] + self.slippage)
            elif last_candle['low'] <= self.current_trade['take_profit']:
                self._close_trade(self.current_trade['take_profit'] + self.slippage)

    def _manage_trade(self, signal, stop_loss, take_profit, last_candle):
        """Verwaltet Trades und eröffnet neue, falls notwendig."""

        # Falls ein neuer Trade in die entgegengesetzte Richtung kommt, schließe den alten Trade und öffne neuen
        if self.current_trade and ((self.current_trade['type'] == "BUY CALL" and signal == "BUY PUT") or
                                   (self.current_trade['type'] == "BUY PUT" and signal == "BUY CALL")):
            self._close_trade(last_candle['close'])  # Aktueller Trade wird geschlossen

        # Falls kein Trade offen ist, kann einer gestartet werden
        if self.current_trade is None and signal in ["BUY CALL", "BUY PUT"]:
            entry_price = last_candle['close'] + self.slippage if signal == "BUY CALL" else last_candle['close'] - self.slippage
            trade_size = self.balance / entry_price  # Alles Kapital in den Trade
            trade = {
                'type': signal,
                'entry_price': entry_price,
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'size': trade_size,
                'entry_balance': self.balance  # Kapital merken
            }
            self.current_trade = trade
            self.trades.append(trade)
            self.balance = 0  # Kapital ist jetzt im Trade

    def _close_trade(self, exit_price):
        """Schließt den aktuellen Trade mit dem gegebenen Exit-Preis."""
        if self.current_trade:
            profit = (exit_price - self.current_trade['entry_price']) * self.current_trade['size']
            if self.current_trade['type'] == "BUY PUT":
                profit *= -1  # Puts funktionieren andersherum

            profit -= self.current_trade['entry_balance'] * self.fee_per_trade  # Gebühren abziehen
            self.balance += self.current_trade['entry_balance']+profit
            self.current_trade = None

    def _calculate_metrics(self):
        """Berechnet die Performance-Kennzahlen des Backtests."""
        equity_array = np.array(self.equity_curve, dtype=np.float64)
        valid_indices = equity_array[:-1] > 0  # Nur nicht-null Werte verwenden
        returns = np.zeros_like(equity_array[:-1])  # Standardmäßig 0 setzen
        returns[valid_indices] = np.diff(equity_array)[valid_indices] / equity_array[:-1][valid_indices]

        sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252) if np.std(returns) > 0 else 0
        max_drawdown = np.max(np.maximum.accumulate(self.equity_curve) - self.equity_curve)
        win_trades = sum(1 for t in self.trades if t['entry_price'] < t['take_profit'])
        loss_trades = sum(1 for t in self.trades if t['entry_price'] > t['stop_loss'])
        win_rate = win_trades / len(self.trades) if self.trades else 0

        results = {
            "Final Balance": self.balance,
            "Total Trades": len(self.trades),
            "Win Rate": win_rate,
            "Sharpe Ratio": sharpe_ratio,
            "Max Drawdown": max_drawdown
        }

        if self.visualize:
            self._plot_results()

        return results

    def _plot_results(self):
        """Visualisiert die Backtest-Ergebnisse."""
        plt.figure(figsize=(12, 6))
        plt.plot(self.equity_curve, label='Equity Curve')
        plt.xlabel('Time')
        plt.ylabel('Balance')
        plt.title('Backtest Performance')
        plt.legend()
        plt.show()
