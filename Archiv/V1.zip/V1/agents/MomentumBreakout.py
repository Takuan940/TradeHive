import numpy as np
import pandas as pd

class MomentumBreakoutAgent:
    def __init__(self,
                 breakout_window=20,
                 ema_trend_filter=True,
                 momentum_filter=True,
                 atr_multiplier_sl=1.5,
                 atr_multiplier_tp=2.5,
                 min_momentum=0,
                 volume_confirmation=True,
                 min_candle_body_ratio=0.6,
                 min_adx_15m=20,
                 momentum_ma_window=10,
                 min_atr_threshold=0.1,
                 slippage_adjustment=0.01,
                 debug=False):
        """
        Initializes the Momentum Breakout Agent with customizable parameters.
        """
        self.breakout_window = breakout_window
        self.ema_trend_filter = ema_trend_filter
        self.momentum_filter = momentum_filter
        self.atr_multiplier_sl = atr_multiplier_sl
        self.atr_multiplier_tp = atr_multiplier_tp
        self.min_momentum = min_momentum
        self.volume_confirmation = volume_confirmation
        self.min_candle_body_ratio = min_candle_body_ratio
        self.min_adx_15m = min_adx_15m
        self.momentum_ma_window = momentum_ma_window
        self.min_atr_threshold = min_atr_threshold
        self.slippage_adjustment = slippage_adjustment
        self.debug = debug
    def get_signal(self, df_5min, df_1min, df_15min):
        """
        Determines a trading signal based on the provided 5min, 1min, and 15min market data.
        """
        if len(df_5min) < self.breakout_window + 1 or len(df_1min) < 15 or len(df_15min) < 50:
            return "HOLD", None, None
        # 🎯 Extract latest values
        last_close_5m = df_5min['close'].iloc[-1]
        last_high_5m = df_5min['high'].iloc[-1]
        last_low_5m = df_5min['low'].iloc[-1]
        last_open_5m = df_5min['open'].iloc[-1]
        last_atr_5m = df_5min['ATR_14'].iloc[-1]
        last_volume_5m = df_5min['volume'].iloc[-1]
        last_adx_15m = df_15min['ADX_14'].iloc[-1]
        last_close_1m = df_1min['close'].iloc[-1]
        last_momentum_1m = df_1min['Momentum_14'].iloc[-1]
        avg_momentum_1m = df_1min['Momentum_14'].rolling(self.momentum_ma_window).mean().iloc[-1]
        ema_20_15m = df_15min['EMA_20'].iloc[-1]
        ema_50_15m = df_15min['EMA_50'].iloc[-1]
        # 📊 Bestimmung der Breakout-Zonen
        breakout_high = df_5min['high'].rolling(self.breakout_window).max().iloc[-2]
        breakout_low = df_5min['low'].rolling(self.breakout_window).min().iloc[-2]
        # ✅ Kerzenkörpergröße berechnen
        body_size_5m = abs(last_close_5m - last_open_5m)
        candle_size_5m = abs(last_high_5m - last_low_5m)
        body_ratio_5m = body_size_5m / candle_size_5m if candle_size_5m != 0 else 0
        # ✅ Trendbestätigung (15-Minuten-Chart)
        trend_long = ema_20_15m > ema_50_15m if self.ema_trend_filter else True
        trend_short = ema_20_15m < ema_50_15m if self.ema_trend_filter else True
        # ✅ Momentum-Bedingung (1-Minuten-Chart)
        momentum_long = last_momentum_1m > self.min_momentum and last_momentum_1m > avg_momentum_1m if self.momentum_filter else True
        momentum_short = last_momentum_1m < -self.min_momentum and last_momentum_1m < avg_momentum_1m if self.momentum_filter else True
        # ✅ Weitere Filter
        valid_atr = last_atr_5m > self.min_atr_threshold
        valid_adx = last_adx_15m >= self.min_adx_15m
        valid_candle_body = body_ratio_5m >= self.min_candle_body_ratio
        valid_volume = last_volume_5m > df_5min['volume'].rolling(self.breakout_window).mean().iloc[
            -1] if self.volume_confirmation else True
        # ✅ Ein- und Ausstiegspreise mit Slippage
        entry_price_long = last_close_5m + self.slippage_adjustment
        stop_loss_long = entry_price_long - (self.atr_multiplier_sl * last_atr_5m)
        take_profit_long = entry_price_long + (self.atr_multiplier_tp * last_atr_5m)
        entry_price_short = last_close_5m - self.slippage_adjustment
        stop_loss_short = entry_price_short + (self.atr_multiplier_sl * last_atr_5m)
        take_profit_short = entry_price_short - (self.atr_multiplier_tp * last_atr_5m)
        # 🟢 **LONG SETUP (BUY CALL)**
        if last_close_5m > breakout_high and trend_long and momentum_long and valid_atr and valid_adx and valid_candle_body and valid_volume:
            if self.debug:
                print(f"BUY CALL Signal erkannt!")
                print(f"Breakout-High: {breakout_high}, Aktueller Close: {last_close_5m}")
                print(f"Trend OK: {trend_long}, Momentum OK: {momentum_long}")
                print(f"ATR OK: {valid_atr}, ADX OK: {valid_adx}")
                print(f"Candle Body OK: {valid_candle_body}, Volume OK: {valid_volume}")
                print(f"Entry: {entry_price_long}, SL: {stop_loss_long}, TP: {take_profit_long}")
            return "BUY CALL", stop_loss_long, take_profit_long
        # 🔴 **SHORT SETUP (BUY PUT)**
        if last_close_5m < breakout_low and trend_short and momentum_short and valid_atr and valid_adx and valid_candle_body and valid_volume:
            if self.debug:
                print(f"BUY PUT Signal erkannt!")
                print(f"Breakout-Low: {breakout_low}, Aktueller Close: {last_close_5m}")
                print(f"Trend OK: {trend_short}, Momentum OK: {momentum_short}")
                print(f"ATR OK: {valid_atr}, ADX OK: {valid_adx}")
                print(f"Candle Body OK: {valid_candle_body}, Volume OK: {valid_volume}")
                print(f"Entry: {entry_price_short}, SL: {stop_loss_short}, TP: {take_profit_short}")
            return "BUY PUT", stop_loss_short, take_profit_short
        # ❌ Kein Signal
        if self.debug:
            print(f"Kein Trade - Bedingungen nicht erfüllt.")
            print(f"Breakout High: {breakout_high}, Breakout Low: {breakout_low}")
            print(f"Trend Long: {trend_long}, Trend Short: {trend_short}")
            print(f"Momentum Long: {momentum_long}, Momentum Short: {momentum_short}")
            print(f"ATR OK: {valid_atr}, ADX OK: {valid_adx}")
            print(f"Candle Body OK: {valid_candle_body}, Volume OK: {valid_volume}")
        return "HOLD", None, None