from MarketDataFetcher import MarketDataFetcher

MarketDataFetcher("SPY", 15*30, 0.8).process_and_save_data()