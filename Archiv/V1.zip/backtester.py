import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


class Backtester:
    def __init__(self, agent, df_5min, df_15min, initial_balance=10000, slippage=0.01, fee_per_trade=0.0001,
                 visualize=False):
        """
        Generic Backtester for trading agents.
        """
        self.agent = agent
        self.df_5min = df_5min
        self.df_15min = df_15min
        self.initial_balance = initial_balance
        self.slippage = slippage
        self.fee_per_trade = fee_per_trade
        self.visualize = visualize

        self.balance = initial_balance
        self.equity_curve = []
        self.trades = []
        self.current_trade = None

    def run_backtest(self):
        """Run the backtest over the available market data."""
        for i in range(len(self.df_5min)):
            current_time = self.df_5min.index[i]
            df_5min_slice = self.df_5min.iloc[:i] if i > 0 else self.df_5min.iloc[:1]
            df_15min_slice = self.df_15min[self.df_15min.index <= current_time]

            if df_5min_slice.empty or df_15min_slice.empty:
                continue  # Verhindert Zugriff auf leere DataFrames

            # Erhalte das Trading-Signal
            signal, stop_loss, take_profit = self.agent.get_signal(df_5min_slice, df_15min_slice)

            # Prüfe zuerst, ob der aktuelle Trade geschlossen werden muss
            if not df_5min_slice.empty:
                self._check_exit_conditions(df_5min_slice.iloc[-1])

                # Danach den Trade verwalten oder einen neuen öffnen
                self._manage_trade(signal, stop_loss, take_profit, df_5min_slice.iloc[-1])

            self.equity_curve.append(self.balance)

        return self._calculate_metrics()

    def _check_exit_conditions(self, last_candle):
        """Prüft, ob der aktuelle Trade geschlossen werden muss."""
        if self.current_trade is None:
            return

        trade_type = self.current_trade['type']

        # Prüfe Stop-Loss und Take-Profit für Calls
        if trade_type == "BUY CALL":
            if last_candle['low'] <= self.current_trade['stop_loss']:
                self._close_trade(self.current_trade['stop_loss'] - self.slippage)
            elif last_candle['high'] >= self.current_trade['take_profit']:
                self._close_trade(self.current_trade['take_profit'] - self.slippage)

        # Prüfe Stop-Loss und Take-Profit für Puts
        elif trade_type == "BUY PUT":
            if last_candle['high'] >= self.current_trade['stop_loss']:
                self._close_trade(self.current_trade['stop_loss'] + self.slippage)
            elif last_candle['low'] <= self.current_trade['take_profit']:
                self._close_trade(self.current_trade['take_profit'] + self.slippage)

    def _manage_trade(self, signal, stop_loss, take_profit, last_candle):
        """Verwaltet Trades und eröffnet neue, falls notwendig."""

        # Falls ein neuer Trade in die entgegengesetzte Richtung kommt, schließe den alten Trade und öffne neuen
        if self.current_trade:
            if ((self.current_trade['type'] == "BUY CALL" and signal == "BUY PUT") or
                    (self.current_trade['type'] == "BUY PUT" and signal == "BUY CALL")):
                self._close_trade(last_candle['close'])  # Aktueller Trade wird geschlossen
            else:
                # Falls bereits ein Trade in der gleichen Richtung läuft, kein neuer Trade
                return  # Keine Eröffnung eines weiteren Trades in der gleichen Richtung

        # Falls kein Trade offen ist, kann einer gestartet werden
        if signal in ["BUY CALL", "BUY PUT"]:
            entry_price = last_candle['close'] + self.slippage if signal == "BUY CALL" else last_candle[
                                                                                                'close'] - self.slippage
            trade_size = self.balance / entry_price  # Alles Kapital in den Trade
            trade = {
                'type': signal,
                'entry_price': entry_price,
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'size': trade_size,
                'entry_balance': self.balance  # Kapital merken
            }
            self.current_trade = trade
            self.trades.append(trade)
            self.balance = 0  # Kapital ist jetzt im Trade

    def _close_trade(self, exit_price):
        """Schließt den aktuellen Trade mit dem gegebenen Exit-Preis und speichert das Ergebnis."""
        if self.current_trade:
            # Fallback, falls exit_price nicht gesetzt wird
            if exit_price is None or np.isnan(exit_price):
                print("⚠ Warnung: exit_price ist None oder NaN! Setze auf letzten Schlusskurs.")
                exit_price = self.df_5min.iloc[-1]['close']  # Fallback auf letzten bekannten Preis

            profit = (exit_price - self.current_trade['entry_price']) * self.current_trade['size']
            if self.current_trade['type'] == "BUY PUT":
                profit *= -1  # Puts funktionieren andersherum

            profit -= self.current_trade['entry_balance'] * self.fee_per_trade  # Gebühren abziehen
            self.balance += self.current_trade['entry_balance'] + profit

            # Fix: exit_price direkt setzen
            self.current_trade['exit_price'] = exit_price
            self.current_trade['closed'] = True  # Status für Debugging setzen

            self.trades.append(self.current_trade.copy())  # Sicherstellen, dass er wirklich gespeichert wird
            self.current_trade = None

    def _calculate_metrics(self):
        """Berechnet Performance-Kennzahlen mit Fixes."""
        equity_array = np.array(self.equity_curve, dtype=np.float64)

        # Fix: Berechnung der Renditen absichern
        returns = np.diff(equity_array) / np.maximum(equity_array[:-1], 1)  # Division durch 0 vermeiden
        returns = returns[~np.isnan(returns)]  # NaN-Werte entfernen

        # Fix: Sharpe Ratio nur berechnen, wenn gültige Renditen vorhanden sind
        sharpe_ratio = round((np.mean(returns) / np.std(returns) * np.sqrt(252)) if np.std(returns) > 0 else 0, 2)

        # Fix: Max Drawdown auf echte Equity-Peaks beziehen
        running_max = np.maximum.accumulate(equity_array)
        drawdowns = running_max - equity_array
        max_drawdown = round(np.max(drawdowns), 2)

        # Fix: Winrate berechnen und speichern
        win_trades = sum(1 for t in self.trades if (t['type'] == "BUY CALL" and t['exit_price'] > t['entry_price']) or
                         (t['type'] == "BUY PUT" and t['exit_price'] < t['entry_price']))
        total_trades = len(self.trades)
        win_rate = round((win_trades / total_trades) * 100, 2) if total_trades > 0 else 0

        results = {
            "Final Balance": round(self.balance, 2),
            "Total Trades": total_trades,
            "Win Rate (%)": win_rate,
            "Sharpe Ratio": sharpe_ratio,
            "Max Drawdown": max_drawdown
        }

        return results

    def _plot_results(self):
        """Visualisiert die Backtest-Ergebnisse."""
        plt.figure(figsize=(12, 6))
        plt.plot(self.equity_curve, label='Equity Curve')
        plt.xlabel('Time')
        plt.ylabel('Balance')
        plt.title('Backtest Performance')
        plt.legend()
        plt.show()
